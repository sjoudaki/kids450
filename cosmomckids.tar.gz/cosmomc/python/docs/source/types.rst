getdist.types
==================================



.. automodule:: getdist.types
   :members:




   