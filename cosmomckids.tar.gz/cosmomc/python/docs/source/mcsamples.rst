getdist.mcsamples
==================================


.. automodule:: getdist.mcsamples
   :members: loadMCSamples

.. autoclass:: getdist.mcsamples.MCSamples
   :members:
   :inherited-members:


.. automodule:: getdist.mcsamples
   :members: MCSamplesError, ParamError, SettingError
   :noindex:


   